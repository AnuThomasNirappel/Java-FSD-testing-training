class Hello
{
	public static void main(String[] args)
	{
	System.out.println("Hello World");
	System.out.print("line2");
	System.out.print("line3");
	}
}